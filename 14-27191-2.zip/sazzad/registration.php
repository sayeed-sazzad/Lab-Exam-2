<?php

	$con = mysqli_connect("localhost","root","","test");
	if(isset($_POST["submit"]))
	{
		$name = $_POST["name"];
		$email = $_POST["email"];
		$userName = $_POST["userName"];
		$password = $_POST["password"];
		$confirmPassword = $_POST["confirmPassword"];
		$gender = $_POST["gender"];
		$d = $_POST["d"];
		$m = $_POST["m"];
		$y = $_POST["y"];
		$date = $d."-".$m ."-".$y ;
		
		if(isset($name) && isset($email) && isset($userName) && isset($password) && isset($name ) && isset($confirmPassword ) && isset($gender) && isset($d) && isset($m) && isset($y)  )
		{
			if($password==$confirmPassword)
			{
				$sql="insert into user values('".$name."','".$email."','".$userName."', '".$password."','".$gender."','".$date."')";
				$query = mysqli_query($con,$sql);
				
				if($query)
				{
					echo "success";
				}
				else
				{
					echo "Failed";
				}
				
			}
		}
		else
		{
			echo "Fill up the information";
		}
		
	}


?>







<fieldset>
    <legend><b>REGISTRATION</b></legend>
	<form action="" method="post">
		<br/>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><input name="name" type="text"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>
					<input name="email" type="text">
					<abbr title="hint: sample@example.com"><b>i</b></abbr>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>User Name</td>
				<td>:</td>
				<td><input name="userName" type="text"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input name="password" type="password"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Confirm Password</td>
				<td>:</td>
				<td><input name="confirmPassword" type="password"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Gender</legend>    
						<input name="gender" type="radio">Male
						<input name="gender" type="radio">Female
						<input name="gender" type="radio">Other
					</fieldset>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Date of Birth</legend>    
						<input name="d" type="text" size="2" />/
						<input name="m" type="text" size="2" />/
						<input name="y" type="text" size="4" />
						<font size="2"><i>(dd/mm/yyyy)</i></font>
					</fieldset>
				</td>
				<td></td>
			</tr>
		</table>
		<hr/>
		<input name="submit" type="submit" value="Submit">
		<input type="reset">
	</form>
</fieldset>