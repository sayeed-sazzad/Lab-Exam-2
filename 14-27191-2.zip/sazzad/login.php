<?php

	session_start();
	$con = mysqli_connect("localhost","root","","test");
	
	if(isset($_POST["submit"]))
	{
		$userName = $_POST["userName"];
		$password = $_POST["password"];
		
		if(isset($userName) && isset($password)
		{
			$sql = "select * from user where username = '".$userName."' and password = '".$userName."';
			
			$query = mysqli_query($con,$sql);
		}
		else
		{
			echo "Fill up the information first";
		}
		
	}
	
	
	

?>



<fieldset>
    <legend><b>LOGIN</b></legend>
    <form>
        <table>
            <tr>
                <td>User Name</td>
				<td>:</td>
                <td><input name="userName" type="text"></td>
            </tr>
            <tr>
                <td>Password</td>
				<td>:</td>
                <td><input name="password" type="password"></td>
            </tr>
        </table>
        <hr />
		<input name="remember" type="checkbox">Remember Me
		<br/><br/>
        <input type="submit" name="submit" value="Submit">        
		<a href="forgot_password.php">Forgot Password?</a>
    </form>
</fieldset>